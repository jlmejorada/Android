package com.example.examenloteria.ui.theme

import androidx.navigation.NavHostController

class PantallaResultado(navController: NavHostController) {

}