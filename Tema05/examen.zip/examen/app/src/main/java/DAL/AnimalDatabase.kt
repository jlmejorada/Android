package DAL

import ENT.MascotaEntity
import ENT.UsuarioEntity
import androidx.room.Database
import androidx.room.RoomDatabase
import kotlinx.coroutines.CoroutineScope

@Database(entities = [UsuarioEntity::class, MascotaEntity::class], version = 1)
abstract class AnimalDatabase: RoomDatabase() {
    abstract fun animalDao(): AnimalDao

    companion object {
        lateinit var coroutine: CoroutineScope
    }

}
