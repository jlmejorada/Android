package com.example.examen

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController

@Composable
fun PantallaDesafio(navController: NavHostController){

    Text( "PantallaDesafio")
}